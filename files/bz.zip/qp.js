function paintQP(qp,bj,showall,showzb)
{
  var alpha='abcdefghijklmno';
  var codebase='.';
  var i=1;
  var j=1;
  m = new Array(15);
  for (i=1;i<16 ;i++ )
  {
      m[i]=new Array(15)
	  for (j=1;j<16 ;j++)
	  {
		  m[i][j]='empty.jpg';
	  }
  } 
  for (i=2;i<15 ;i++ )
  {
	  m[i][1]='el.jpg';
	  m[i][15]='er.jpg'
  }
for (j=2;j<15 ;j++ )
{
m[1][j]='et.jpg';
m[15][j]='eb.jpg';
}

m[1][1]='etl.jpg';
m[1][15]='etr.jpg';
m[15][1]='ebl.jpg';
m[15][15]='ebr.jpg';

m[8][8]='ei.jpg';
m[3][3]='ei.jpg';
m[3][12]='ei.jpg';
m[12][3]='ei.jpg';
m[12][12]='ei.jpg';

var t=new Array(15);
for (i=1;i<16 ;i++ )
{
  t[i]=new Array(15);
  for (j=1;j<16 ;j++ )
  {
  t[i][j]=0;
  }
}
var a=1;
var b=1;
var p='b.jpg';
qp=iwzq2str(qp);
var x=qp.length / 2;
for (i=0;i<x;i++ )
{
	a=qp.charCodeAt(i*2)-64;
	b=qp.charCodeAt(i*2+1)-64;
	p='b.jpg';
	if (i%2!=0)
	{
       p='w.jpg';  
	}
	m[b][a]=p;
//	t[b][a]=i+1;
	t[b][a]=sz2img(i+1);
}
if (bj!='')
{
bj=iwzq2str(bj);
var s1=bj.split('|');
for (k=0;k<s1.length;k++)
{
	var ma=s1[k].split(',');
	a=ma[0].charCodeAt(0)-64;
    b=ma[0].charCodeAt(1)-64;
	t[b][a]=ma[1];
}

}
v11=1;
v12=16;
h11=1;
h12=16;
if (showall!=0)
{
v11=getv11(qp);
v12=getv12(qp);
//��������
h11=geth11(qp);
h12=geth12(qp);

	v11=v11-showall;
	v12=v12+showall;
	h11=h11-showall;
	h12=h12+showall;
}
if (v11<0){v11=1}
if (v12>16){v12=16}
if (h11<0){h11=1}
if (h12>16){h12=16}

wi=(v12-v11+1)*25;
document.write("<table width='"+wi+"' cellpadding='0' cellspacing='0' align='center'>")

for (i=h11;i<h12 ;i++ )

{
document.write("<tr>");
	for (j=v11;j<v12;j++)
	{
		if (t[i][j]%2!=0)
		{
		co="ffffff";
		}
		else
		{
		co="000000";
		}
		if (isNaN(t[i][j]))
		{
			co="#660000";
		}
		document.write("<td background='"+codebase+"/img/"+m[i][j]+"' align='center' valign='center'  style='font-family:Arial;font-size:9pt;color:"+co+";cursor:crosshair' width='25' height='25'><B>");
		if (t[i][j]!='')
		{
		  document.write(t[i][j].toString())
		}
		else
        {
		document.write("&nbsp;")

		}	
document.write("</B></td>");
	}
document.write("<td style='font-size:9pt;font-family:arial' height='25' width='25'>");
if (showzb!=0)
{
	document.write(16-i);
}
document.write("</td>");
document.write ("</tr>");
}
if (showzb!=0)
{
	document.write("<tr align=center>");
	for (i = v11; i <v12; i++)
	{
		document.write("<td height='25' width='25'><span style='font-size:9pt;font-family:arial'>");
		document.write(alpha.charAt(i-1));
		document.write ("</span></td>");
	}
	document.write("</tr>");
}
document.write("</table>");
document.write("���ף�<font color=#ff0000 style='word-break:break-all;'>"+str2iwzq(qp)+"</font><br>");
}


function iwzq2str(qp)
{
	qp=qp.toUpperCase();
	qp=qp.replace(/15/g,"A");
	qp=qp.replace(/14/g,"B");
	qp=qp.replace(/13/g,"C");
	qp=qp.replace(/12/g,"D");
	qp=qp.replace(/11/g,"E");
	qp=qp.replace(/10/g,"F");
	qp=qp.replace(/9/g,"G");
	qp=qp.replace(/8/g,"H");
	qp=qp.replace(/7/g,"I");
	qp=qp.replace(/6/g,"J");
	qp=qp.replace(/5/g,"K");
	qp=qp.replace(/4/g,"L");
	qp=qp.replace(/3/g,"M");
	qp=qp.replace(/2/g,"N");
	qp=qp.replace(/1/g,"O");
    return qp;
}

function str2iwzq(qp)
{
   var v='';
   for (i=0;i<qp.length/2;i++)
   {
	   v=v+qp.substr(i*2,1);
	   n=qp.charCodeAt(i*2+1)-64;
	   v=v+n.toString();
   }
return v.toLowerCase();
}

function getv11(qp)
{
	var m11=15;
	for (i=0;i<qp.length / 2 ;i++ )
	{
		s12=qp.charCodeAt(i*2)-64;
		if (m11>s12)
		{
			m11=s12;
		}
	}
	return m11;
}//������С

function getv12(qp)
{
	var m12=1;
	for (i=0;i<qp.length / 2;i++ )
	{
		s12=qp.charCodeAt(i*2)-64;
		if (m12<s12)
		{
			m12=s12;
		}
	}
	return m12+1;
}//�������

function geth11(qp)
{
	var m13=15;
	for (i=0;i<qp.length / 2;i++ )
	{
		s12=qp.charCodeAt(i*2+1)-64;
		if (m13>s12)
		{
			m13=s12
		}
	}
	return m13;
}//������С


function geth12(qp)
{
	var m14=1;
	for (i=0;i<qp.length / 2;i++ )
	{
		s12=qp.charCodeAt(i*2+1)-64;
		if (m14<s12)
		{
			m14=s12
		}
	}
	return m14+1;
}//�������

function sz2img(sz)
{
  if (sz % 2==0)
  {
	  p='w'
  }
  else
	{
  p='b'
  }
  if (sz>=10)
  {
	  p+='s'
  }
  var strsz=sz.toString();
  var returnstr='';
  for (i=0;i<strsz.length;i++)
  {
     returnstr+="<img src='img/"+p+strsz.substr(i,1)+".jpg'>";
  }
  return returnstr
}